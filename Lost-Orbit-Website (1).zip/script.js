const products = [
  {
    id: "orbit-tee",
    name: "Orbit Tee",
    price: 45,
    sizes: ["S", "M", "L", "XL"],
    image: ""
  },
  {
    id: "lost-hoodie",
    name: "Lost Hoodie",
    price: 85,
    sizes: ["S", "M", "L", "XL"],
    image: ""
  },
  {
    id: "void-pants",
    name: "Void Pants",
    price: 95,
    sizes: ["S", "M", "L", "XL"],
    image: ""
  }
];

let cart = JSON.parse(localStorage.getItem("lostOrbitCart") || "[]");

const money = n => `$${n.toFixed(2)} AUD`;

function save() {
  localStorage.setItem("lostOrbitCart", JSON.stringify(cart));
  renderCart();
}

function renderProducts() {
  const root = document.getElementById("products");
  root.innerHTML = products.map(p => `
    <article class="product-card">
      <div class="product-image">
        ${p.image ? `<img src="${p.image}" alt="${p.name}">` : `<div class="placeholder">ADD YOUR PRODUCT PHOTO</div>`}
      </div>
      <div class="product-info">
        <span class="product-name">${p.name}</span>
        <span class="product-price">${money(p.price)}</span>
      </div>
      <select id="size-${p.id}" aria-label="Choose size for ${p.name}">
        ${p.sizes.map(s => `<option>${s}</option>`).join("")}
      </select>
      <button class="button add" onclick="addToCart('${p.id}')">Add to cart</button>
    </article>
  `).join("");
}

function addToCart(id) {
  const p = products.find(x => x.id === id);
  const size = document.getElementById(`size-${id}`).value;
  const existing = cart.find(x => x.id === id && x.size === size);
  if (existing) existing.qty++;
  else cart.push({ id, size, qty: 1 });
  save();
  openCart();
}

function changeQty(id, size, delta) {
  const item = cart.find(x => x.id === id && x.size === size);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter(x => !(x.id === id && x.size === size));
  save();
}

function removeItem(id, size) {
  cart = cart.filter(x => !(x.id === id && x.size === size));
  save();
}

function renderCart() {
  const root = document.getElementById("cartItems");
  const count = cart.reduce((sum, x) => sum + x.qty, 0);
  document.getElementById("cartCount").textContent = count;
  if (!cart.length) {
    root.innerHTML = `<div class="empty">Your cart is empty.</div>`;
  } else {
    root.innerHTML = cart.map(item => {
      const p = products.find(x => x.id === item.id);
      return `
        <div class="cart-item">
          <div class="cart-thumb">${p.image ? `<img src="${p.image}" alt="">` : ""}</div>
          <div>
            <h3>${p.name}</h3>
            <p>Size: ${item.size} · ${money(p.price)}</p>
            <div class="qty">
              <button onclick="changeQty('${item.id}','${item.size}',-1)">−</button>
              <span>${item.qty}</span>
              <button onclick="changeQty('${item.id}','${item.size}',1)">+</button>
            </div>
            <button class="remove" onclick="removeItem('${item.id}','${item.size}')">REMOVE</button>
          </div>
          <strong>${money(p.price * item.qty)}</strong>
        </div>
      `;
    }).join("");
  }
  const total = cart.reduce((sum, item) => {
    const p = products.find(x => x.id === item.id);
    return sum + p.price * item.qty;
  }, 0);
  document.getElementById("cartTotal").textContent = money(total);
}

function openCart() {
  document.getElementById("cartDrawer").classList.add("open");
  document.getElementById("overlay").classList.add("active");
}
function closeCart() {
  document.getElementById("cartDrawer").classList.remove("open");
  document.getElementById("overlay").classList.remove("active");
}

document.getElementById("openCart").onclick = openCart;
document.getElementById("closeCart").onclick = closeCart;
document.getElementById("overlay").onclick = closeCart;

document.getElementById("checkout").onclick = () => {
  if (!cart.length) return alert("Your cart is empty.");
  alert("Checkout is not connected yet. Add your Stripe Checkout payment link or backend in script.js.");
};

renderProducts();
renderCart();
