LOST ORBIT — FREE STORE STARTER
================================

This is a static clothing-store starter for Lost Orbit.

Included:
- Responsive homepage
- Product grid
- Product sizes
- Add to cart
- Quantity controls
- Remove from cart
- Cart saved in the browser
- AUD pricing
- Mobile layout
- GitHub Pages compatible

IMPORTANT: The checkout button is intentionally not connected to real payments yet.
A static website should not contain secret payment API keys.

HOW TO PUT IT ONLINE FOR FREE
-----------------------------
1. Create a GitHub account.
2. Create a new PUBLIC repository called "lost-orbit-store".
3. Upload index.html, style.css and script.js.
4. Open repository Settings > Pages.
5. Choose "Deploy from a branch".
6. Select the main branch and root folder.
7. Save.
8. GitHub will give you a free address similar to:
   https://YOUR-USERNAME.github.io/lost-orbit-store/

ADDING YOUR PRODUCTS
--------------------
Open script.js and edit the "products" array.
You can change:
- name
- price
- sizes
- image

For images, upload your product photos into the repository and use paths like:
image: "images/black-tee.jpg"

REAL PAYMENTS
-------------
For real payments, use a payment provider such as Stripe Checkout.
Do NOT put a Stripe secret key in index.html or script.js.

A secure setup is:
Customer -> your site -> Stripe Checkout -> payment -> order confirmation.

For a truly automatic store (payment + order creation + stock management),
you will need a small server/serverless function or a hosted checkout/payment-link
system. The website itself can still be hosted for free.

NEXT CUSTOMIZATION
------------------
Replace the demo product names/photos/prices with your actual Lost Orbit
collection and add your logo. You can also change the CSS to match your exact
brand style.
